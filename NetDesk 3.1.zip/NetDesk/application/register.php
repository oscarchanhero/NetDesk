<?php
$user = $_POST['username'];
$pwd = $_POST['password'];
$nickname = $_POST['nickname'];
require('basic.php');
include_once('conn.php');
    $sql = "INSERT INTO user(username,pwd,nickname) VALUE('$user','$pwd','$nickname')";
    $check_sql = "select * from `user` where username='$user'";
        $result = mysqli_query($conn,$check_sql);
        if (mysqli_num_rows($result)>0){
            $flag = 2;//已注册
        }else{
            $path = $root_path.'/'.$user;
            mkdir($path,0777,true);
            if(mysqli_query($conn,$sql)){
                $flag = 1;
            }else{
                unlink($path);
                $flag = 0;
            };
        }
mysqli_close($conn);
echo $flag;