<?php
include('basic.php');
$path = $_GET['path'];
$full_path = $root_path.'/'.$path;
header("content-disposition:attachment;filename=".substr($path,strrpos($path,"/",0)+1));
header("content-length:".filesize($full_path));
readfile($full_path);
