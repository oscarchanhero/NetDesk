<?php
if (isset($_SESSION['username'])){
    echo "yes";
}else{
    echo "no";
}