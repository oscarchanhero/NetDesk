<?php
session_start();
if (isset($_SESSION['username'])){
    $user_data['name']=$_SESSION['nickname'];
    $user_data['username']=$_SESSION['username'];
    $user_data['flag']=1;
    require("view.php");
    require("basic.php");
    $user_data['file'] = GetAllFiles($path,$root_path);
}else{
    $user_data['flag']=0;
}
echo json_encode($user_data);