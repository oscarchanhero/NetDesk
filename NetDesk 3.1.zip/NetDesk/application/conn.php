<?php
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "netdesk";
//创建连接
$conn = new mysqli($servername,$username,$password,$dbname);
