<?php
session_start();
$user = $_POST['username'];
$pwd = $_POST['password'];
/**
 * 数据库验证
 */
include_once('conn.php');
$sql = "select * from `user` where username='$user' and pwd='$pwd'";
$result = mysqli_query($conn,$sql);
if (mysqli_num_rows($result)>0){
    $row =mysqli_fetch_assoc($result);
    $_SESSION['username']= $user;
    $_SESSION['nickname']= $row['nickname'];//获取数据库昵称等信息
    $flag = 1;
}else{
    $flag =0 ;
}
mysqli_close($conn);

echo $flag;