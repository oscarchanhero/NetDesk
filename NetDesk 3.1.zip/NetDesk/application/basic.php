<?php
$root_path = 'D:\netdesk'.'/'.$_SESSION['username'];
