<?php
    function GetAllDirs($path="",$root_path){
        $path = urldecode($path);
        $full_path = $root_path.'/'.$path;
        $file_data = array();$result = array();
        if(is_dir($full_path)){
            $handle = opendir($full_path);
            if($handle){
                while(($file = readdir($handle)) !== false){
                    if($file != "." && $file != ".."){
                        if(is_dir($full_path.'/'.$file)){
                            array_push($file_data,$file);
                        }
                    }
                }
                $result['data'] = $file_data;
                $result['path'] = $path;

            }
            closedir($handle);
            echo json_encode($result);
        }else{
            echo "文件夹不存在";
        }
    }
    require ('basic.php');
    $path = $_GET['path'];
    GetAllDirs($path,$root_path);
