<?php
require("view.php");
require("basic.php");
GetAllFiles($path,$root_path);