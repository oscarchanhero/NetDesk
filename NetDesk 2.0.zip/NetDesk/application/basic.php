<?php
$root_path = 'D:\01_software';