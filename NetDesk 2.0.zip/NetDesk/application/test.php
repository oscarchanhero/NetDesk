<?php
require("basic.php");
require("view.php");
$path = $_GET['path'];
echo $path;
GetAllFiles($path,$root_path);