<?php
include('basic.php');
$path = $_GET['path'];
$full_path = $root_path.'/'.$path;
if(!file_exists($full_path)){
    mkdir($full_path,0777,true);
    echo "创建成功";
}else{
    echo "已存在同名文件";
}