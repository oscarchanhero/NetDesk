<?php
include('basic.php');
$path = $_GET['path'];
$new_name = $_GET['NewName'];
$full_path = $root_path.$path;
if(file_exists($full_path)){
    if(rename($full_path,substr($full_path,0,strrpos($full_path,"/",0))."/".$new_name)){
        echo "重命名成功";
    }else{
        echo "重命名失败";
    }
}else{
    echo "文件不存在";
}