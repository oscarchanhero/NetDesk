<?php
include('basic.php');
$path = $_GET['path'];
$new_path = $_GET['NewPath'];
$full_path = $root_path.$path;
if(file_exists($full_path)){
    if(rename($full_path,$root_path.$new_path)){
        echo "移动成功";
    }else{
        echo "移动失败";
    }
}else{
    echo "文件不存在";
}