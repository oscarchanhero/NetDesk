<?php
    function GetAllFiles($path="",$root_path){
        $path = urldecode($path);
        $full_path = $root_path.'/'.$path;
        $file_data = array();$result = array();
        if(is_dir($full_path)){
            $handle = opendir($full_path);
            if($handle){
                while(($file = readdir($handle)) !== false){
                    if($file != "." && $file != ".."){
                        filetype($full_path.'/'.$file) == "dir" ? $type = "dir" : $type = substr($file,strrpos($file,".",0)+1);
                        $data = array("name"=>$file,"type"=>$type,"size"=>filesize($full_path.'/'.$file),"ctime"=>filectime($full_path.'/'.$file));
                        array_push($file_data,$data);
                    }
                }
                    $result['data'] = $file_data;
                    $result['path'] = $path;

            }
            closedir($handle);
            echo json_encode($result);
        }else{
            echo "文件夹不存在";
        }
    }
